package com.rastreabilidadeInterna.fracionamento;

/**
 * Created by Felipe Pereira on 26/03/2015.
 */
public class ModelIndexBaixado {
    public String selo;
    public String tipo;
    public String data;
    public String fabricante;
    public String sif;
    public String lote;
    public String dataFabricacao;
    public String dataValidade;
}
